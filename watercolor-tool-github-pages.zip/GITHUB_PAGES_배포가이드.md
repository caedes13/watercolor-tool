# GitHub Pages 배포 가이드

이 폴더의 파일들을 GitHub Pages에 올리면 iPhone Safari에서 URL로 열고, 홈 화면에 앱처럼 추가할 수 있습니다.

## 1. GitHub 계정 만들기

1. https://github.com 접속
2. Sign up 선택
3. 이메일, 비밀번호, 사용자 이름 생성
4. 이메일 인증 완료

## 2. 새 저장소 만들기

1. GitHub 오른쪽 위의 + 버튼 선택
2. New repository 선택
3. Repository name 입력
   - 추천: `watercolor-tool`
4. Public 선택
   - 무료 GitHub Pages를 쓰려면 public이 가장 단순합니다.
5. Add a README file은 체크하지 않아도 됩니다.
6. Create repository 선택

## 3. 파일 업로드

저장소 화면에서 다음 파일을 모두 업로드합니다.

- `index.html`
- `shinhan-watercolor-tool.html`
- `manifest.webmanifest`
- `sw.js`
- `watercolor-icon.svg`
- `watercolor-icon-180.png`

업로드 순서:

1. Add file 선택
2. Upload files 선택
3. 위 파일들을 드래그해서 넣기
4. 아래 Commit changes 버튼 선택

주의: `outputs` 폴더 자체를 올리는 것이 아니라, 폴더 안의 파일들이 저장소 첫 화면에 바로 보이게 올리는 것이 가장 쉽습니다.

## 4. GitHub Pages 켜기

1. 저장소 상단의 Settings 선택
2. 왼쪽 메뉴에서 Pages 선택
3. Build and deployment 영역에서 Source를 Deploy from a branch로 선택
4. Branch를 `main`으로 선택
5. 폴더는 `/root` 선택
6. Save 선택

몇 분 기다리면 접속 주소가 표시됩니다.

보통 주소 형태:

`https://사용자이름.github.io/watercolor-tool/`

## 5. iPhone에서 앱처럼 쓰기

1. iPhone Safari에서 위 URL 접속
2. 화면 아래 공유 버튼 선택
3. 홈 화면에 추가 선택
4. 이름을 `수채화 조색` 정도로 지정
5. 추가 선택

이후 홈 화면 아이콘으로 실행하면 앱처럼 열립니다.

## 문제가 생겼을 때

- 색이 안 뜨면 파일앱 미리보기가 아니라 Safari URL로 열었는지 확인합니다.
- URL 접속 시 404가 뜨면 GitHub Pages 설정에서 Branch가 `main`, 폴더가 `/root`인지 확인합니다.
- 홈 화면 추가 후 예전 화면이 보이면 Safari에서 새로고침 후 다시 홈 화면에 추가합니다.
- 파일을 수정해서 다시 올린 뒤 반영이 늦으면 1~5분 기다린 뒤 새로고침합니다.
